#include "distributed/metadata_server.h"
#include "common/util.h"
#include "filesystem/directory_op.h"
#include <fstream>

namespace chfs
{
  inline auto MetadataServer::bind_handlers()
  {
    server_->bind("mknode",
                  [this](u8 type, inode_id_t parent, std::string const &name)
                  {
                    return this->mknode(type, parent, name);
                  });
    server_->bind("unlink", [this](inode_id_t parent, std::string const &name)
                  { return this->unlink(parent, name); });
    server_->bind("lookup", [this](inode_id_t parent, std::string const &name)
                  { return this->lookup(parent, name); });
    server_->bind("get_block_map",
                  [this](inode_id_t id)
                  { return this->get_block_map(id); });
    server_->bind("alloc_block",
                  [this](inode_id_t id)
                  { return this->allocate_block(id); });
    server_->bind("free_block",
                  [this](inode_id_t id, block_id_t block, mac_id_t machine_id)
                  {
                    return this->free_block(id, block, machine_id);
                  });
    server_->bind("readdir", [this](inode_id_t id)
                  { return this->readdir(id); });
    server_->bind("get_type_attr",
                  [this](inode_id_t id)
                  { return this->get_type_attr(id); });
  }

  inline auto MetadataServer::init_fs(const std::string &data_path)
  {
    /**
     * Check whether the metadata exists or not.
     * If exists, we wouldn't create one from scratch.
     */
    bool is_initialed = is_file_exist(data_path);

    auto block_manager = std::shared_ptr<BlockManager>(nullptr);
    if (is_log_enabled_)
    {
      block_manager =
          std::make_shared<BlockManager>(data_path, KDefaultBlockCnt, true);
    }
    else
    {
      block_manager = std::make_shared<BlockManager>(data_path, KDefaultBlockCnt);
    }

    CHFS_ASSERT(block_manager != nullptr, "Cannot create block manager.");

    if (is_initialed)
    {
      auto origin_res = FileOperation::create_from_raw(block_manager);
      std::cout << "Restarting..." << std::endl;
      if (origin_res.is_err())
      {
        std::cerr << "Original FS is bad, please remove files manually."
                  << std::endl;
        exit(1);
      }

      operation_ = origin_res.unwrap();
    }
    else
    {
      operation_ = std::make_shared<FileOperation>(block_manager,
                                                   DistributedMaxInodeSupported);
      std::cout << "We should init one new FS..." << std::endl;
      /**
       * If the filesystem on metadata server is not initialized, create
       * a root directory.
       */
      auto init_res = operation_->alloc_inode(InodeType::Directory);
      if (init_res.is_err())
      {
        std::cerr << "Cannot allocate inode for root directory." << std::endl;
        exit(1);
      }

      CHFS_ASSERT(init_res.unwrap() == 1, "Bad initialization on root dir.");
    }

    running = false;
    num_data_servers =
        0; // Default no data server. Need to call `reg_server` to add.

    if (is_log_enabled_)
    {
      if (may_failed_)
        operation_->block_manager_->set_may_fail(true);
      commit_log = std::make_shared<CommitLog>(operation_->block_manager_,
                                               is_checkpoint_enabled_);
    }

    bind_handlers();

    /**
     * The metadata server wouldn't start immediately after construction.
     * It should be launched after all the data servers are registered.
     */
  }

  MetadataServer::MetadataServer(u16 port, const std::string &data_path,
                                 bool is_log_enabled, bool is_checkpoint_enabled,
                                 bool may_failed)
      : is_log_enabled_(is_log_enabled), may_failed_(may_failed),
        is_checkpoint_enabled_(is_checkpoint_enabled)
  {
    server_ = std::make_unique<RpcServer>(port);
    init_fs(data_path);
    if (is_log_enabled_)
    {
      commit_log = std::make_shared<CommitLog>(operation_->block_manager_,
                                               is_checkpoint_enabled);
    }
  }

  MetadataServer::MetadataServer(std::string const &address, u16 port,
                                 const std::string &data_path,
                                 bool is_log_enabled, bool is_checkpoint_enabled,
                                 bool may_failed)
      : is_log_enabled_(is_log_enabled), may_failed_(may_failed),
        is_checkpoint_enabled_(is_checkpoint_enabled)
  {
    server_ = std::make_unique<RpcServer>(address, port);
    init_fs(data_path);
    if (is_log_enabled_)
    {
      commit_log = std::make_shared<CommitLog>(operation_->block_manager_,
                                               is_checkpoint_enabled);
    }
  }

  // {Your code here}
  auto MetadataServer::mknode(u8 type, inode_id_t parent, const std::string &name)
      -> inode_id_t
  {
    // TODO: Implement this function.
    // UNIMPLEMENTED();

    InodeType inode_type = InodeType::Unknown;
    if (type == RegularFileType)
    {
      inode_type = InodeType::FILE;
    }
    else if (type == DirectoryType)
    {
      inode_type = InodeType::Directory;
    }

    // inode_id_t inode_id = operation_->alloc_inode(inode_type);
    for (auto &item : meta_mtx)
    {
      item.lock();
    }

    auto res = operation_->mk_helper(parent, name.data(), inode_type);

    for (int i = MetaMtxNum - 1; i >= 0; i--)
    {
      meta_mtx[i].unlock();
    }

    if (res.is_ok())
    {
      return res.unwrap();
    }
    else
    {
      return 0;
    }
  }

  // {Your code here}
  auto MetadataServer::unlink(inode_id_t parent, const std::string &name)
      -> bool
  {
    // TODO: Implement this function.
    // UNIMPLEMENTED();
    for (auto &item : meta_mtx)
    {
      item.lock();
    }
    auto res = operation_->lookup(parent, name.data());
    if (res.is_err())
    {
      for (int i = MetaMtxNum - 1; i >= 0; i--)
      {
        meta_mtx[i].unlock();
      }
      return false;
    }
    else
    {
      inode_id_t inode_id = res.unwrap();
      std::vector<BlockInfo> blockinfo = get_block_map(inode_id);
      for (auto itr = blockinfo.begin(); itr != blockinfo.end(); itr++)
      {
        block_id_t block_id = std::get<0>(*itr);
        mac_id_t mac_id = std::get<1>(*itr);
        // version_t version = std::get<2>(*itr);
        auto pair = clients_.find(mac_id);
        auto cli_res = pair->second->call("free_block", block_id);
      }
    }

    ChfsNullResult result = operation_->unlink(parent, name.data());
    for (int i = MetaMtxNum - 1; i >= 0; i--)
    {
      meta_mtx[i].unlock();
    }

    if (result.is_ok())
    {
      return true;
    }

    return false;
  }

  // {Your code here}
  auto MetadataServer::lookup(inode_id_t parent, const std::string &name)
      -> inode_id_t
  {
    // TODO: Implement this function.
    // UNIMPLEMENTED();
    auto res = operation_->lookup(parent, name.data());
    if (res.is_ok())
    {
      return res.unwrap();
    }

    return 0;
  }

  // {Your code here}
  auto MetadataServer::get_block_map(inode_id_t id) -> std::vector<BlockInfo>
  {
    // TODO: Implement this function.
    // UNIMPLEMENTED();
    std::vector<BlockInfo> block_info;

    // std::string src = operation_->read_file(id).unwrap();
    ChfsResult<std::vector<u8>> result = operation_->read_file(id);
    std::vector<u8> buffer = result.unwrap();

    auto blockinfo_size = sizeof(block_id_t) + sizeof(mac_id_t) + sizeof(version_t);
    for (int i = 0; i < buffer.size(); i += blockinfo_size)
    {
      block_id_t block_id = *(block_id_t *)(buffer.data() + i);
      mac_id_t mac_id = *(block_id_t *)(buffer.data() + i + sizeof(block_id_t));
      version_t version = *(block_id_t *)(buffer.data() + i + sizeof(block_id_t) + sizeof(mac_id_t));

      block_info.emplace_back(block_id, mac_id, version);
    }

    return block_info;
  }

  // {Your code here}
  auto MetadataServer::allocate_block(inode_id_t id) -> BlockInfo
  {
    // TODO: Implement this function.
    // UNIMPLEMENTED();

    BlockInfo blockinfo;
    bool find_a_mac = false;

    for (auto itr = clients_.begin(); itr != clients_.end(); itr++)
    {
      mac_id_t mac_id = itr->first;
      std::shared_ptr<RpcClient> cli = itr->second;
      auto res = cli->call("alloc_block");
      if (res.is_err())
      {
        continue;
      }
      else
      {
        std::pair<block_id_t, version_t> block_info = res.unwrap()->as<std::pair<block_id_t, version_t>>();
        blockinfo = std::tuple(block_info.first, mac_id, block_info.second);
        find_a_mac = true;
        break;
      }
    }

    if (find_a_mac)
    {
      ChfsResult<std::vector<u8>> result = operation_->read_file(id);
      std::vector<u8> buffer = result.unwrap();

      std::vector<u8> content(sizeof(BlockInfo));
      *((block_id_t *)(content.data())) = std::get<0>(blockinfo);
      *((mac_id_t *)(content.data() + sizeof(block_id_t))) = std::get<1>(blockinfo);
      *((version_t *)(content.data() + sizeof(block_id_t) + sizeof(mac_id_t))) = std::get<2>(blockinfo);

      buffer.insert(buffer.end(), content.begin(), content.end());

      operation_->write_file(id, buffer);
    }

    return blockinfo;
  }

  // {Your code here}
  auto MetadataServer::free_block(inode_id_t id, block_id_t block_id,
                                  mac_id_t machine_id) -> bool
  {
    // TODO: Implement this function.
    // UNIMPLEMENTED();
    bool has_find_block = false;

    std::vector<BlockInfo> block_info = this->get_block_map(id);
    std::vector<u8> buffer;

    for (auto itr = block_info.begin(); itr != block_info.end(); itr++)
    {
      block_id_t bid = std::get<0>(*itr);
      mac_id_t mac_id = std::get<1>(*itr);
      version_t version = std::get<2>(*itr);

      if (mac_id == machine_id && bid == block_id)
      {
        has_find_block = true;
        continue;
      }

      std::vector<u8> content(sizeof(BlockInfo));
      *((block_id_t *)(content.data())) = bid;
      *((mac_id_t *)(content.data() + sizeof(block_id_t))) = mac_id;
      *((version_t *)(content.data() + sizeof(block_id_t) + sizeof(mac_id_t))) = version;

      buffer.insert(buffer.end(), content.begin(), content.end());
    }

    ///////////////////
    if (has_find_block)
    {
      operation_->write_file(id, buffer);

      auto itr = clients_.find(machine_id);
      std::shared_ptr<RpcClient> cli;
      if (itr != clients_.end())
      {
        cli = itr->second;

        auto res = cli->call("free_block", block_id);
        if (res.is_ok())
        {
          return true;
        }
      }
    }

    return false;
  }

  // {Your code here}
  auto MetadataServer::readdir(inode_id_t node)
      -> std::vector<std::pair<std::string, inode_id_t>>
  {
    // TODO: Implement this function.
    // UNIMPLEMENTED();
    ChfsResult<std::vector<u8>> result = operation_->read_file(node);
    std::vector<u8> buffer = result.unwrap();
    std::string src(buffer.begin(), buffer.end());

    std::list<DirectoryEntry> entry_list;
    parse_directory(src, entry_list);

    std::vector<std::pair<std::string, inode_id_t>> vector;
    for (auto itr = entry_list.begin(); itr != entry_list.end(); itr++)
    {
      vector.emplace_back(itr->name, itr->id);
    }
    return vector;
  }

  // {Your code here}
  auto MetadataServer::get_type_attr(inode_id_t id)
      -> std::tuple<u64, u64, u64, u64, u8>
  {
    // TODO: Implement this function.
    // UNIMPLEMENTED();
    FileAttr attr = operation_->inode_manager_->get_attr(id).unwrap();
    InodeType inode_type = operation_->inode_manager_->get_type(id).unwrap();

    u8 type = static_cast<u8>(inode_type);

    std::tuple<u64, u64, u64, u64, u8> type_attr(attr.size, attr.atime, attr.mtime, attr.ctime, type);

    return type_attr;
  }

  auto MetadataServer::reg_server(const std::string &address, u16 port,
                                  bool reliable) -> bool
  {
    num_data_servers += 1;
    auto cli = std::make_shared<RpcClient>(address, port, reliable);
    clients_.insert(std::make_pair(num_data_servers, cli));

    return true;
  }

  auto MetadataServer::run() -> bool
  {
    if (running)
      return false;

    // Currently we only support async start
    server_->run(true, num_worker_threads);
    running = true;
    return true;
  }

} // namespace chfs